// Main.js

// Initialize the cart as an empty array
let cart = [];

// Function to add items to the cart
function addToCart(productName, productPrice) {
    // Add the product to the cart array
    cart.push({ name: productName, price: productPrice });
    updateCartUI();
}

// Function to update the cart UI
function updateCartUI() {
    const cartItemsContainer = document.getElementById("cart-items");
    const totalPriceElement = document.getElementById("total-price");

    // Clear existing items in the cart display
    cartItemsContainer.innerHTML = "";

    // Re-render all cart items
    let total = 0;
    cart.forEach((item, index) => {
        const cartItem = document.createElement("li");
        cartItem.textContent = `${item.name} - $${item.price}`;
        
        // Add a remove button
        const removeButton = document.createElement("button");
        removeButton.textContent = "Remove";
        removeButton.onclick = () => {
            removeFromCart(index);
        };

        cartItem.appendChild(removeButton);
        cartItemsContainer.appendChild(cartItem);

        total += item.price;
    });

    // Update total price
    totalPriceElement.textContent = total.toFixed(2);
}

// Function to remove an item from the cart
function removeFromCart(index) {
    cart.splice(index, 1); // Remove item at the given index
    updateCartUI(); // Update the cart display
}

// Function to handle checkout
function checkout() {
    if (cart.length === 0) {
        alert("Your cart is empty!");
        return;
    }
    alert("Proceeding to checkout...");
    cart = []; // Clear the cart after checkout
    updateCartUI();
}
